from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
def button_menu():
    markup = InlineKeyboardMarkup()
    button_gid = InlineKeyboardButton("Git", url= "https://github.com/Molokota/justcode" )
    button_balance = InlineKeyboardButton("Баланс", callback_data="button_money()")
    markup.add(button_gid, button_balance)
    return markup
b = button_menu()

def button_money():
    markup = InlineKeyboardMarkup()
    button_out = InlineKeyboardButton("вывод", callback_data="Вы вывели средства")
    button_add = InlineKeyboardButton("пополнить", callback_data="Вы пополнили баланс")
    markup.add(button_out, button_add)
    return markup