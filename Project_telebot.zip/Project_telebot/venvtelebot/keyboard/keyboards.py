import random

from telebot.types import ReplyKeyboardMarkup, KeyboardButton
# from telebot.types import KeyboardMarkup, KeyboardButton 
from ganre.action import action
from ganre.adventures import adventures
from ganre.comedies import comedies
from ganre.fantastic import fantastic


# def button_menu():
#     markup = ReplyKeyboardMarkup()
#     action_id_random = (random.choice(action))
#     button_action = KeyboardButton("Боевики", f"https://www.kinopoisk.ru/film/{action_id_random}" )

#     action_id_adventures = (random.choice(adventures))
#     button_adventures = KeyboardButton("Приключения", f"https://www.kinopoisk.ru/film/{action_id_")

#     action_id_comedies = (random.choice(comedies))
#     button_comedies = KeyboardButton("Комедии", f"https://www.kinopoisk.ru/film/{action_id_comedies}")

    
#     action_id_fantastic = (random.choice(fantastic))
#     button_fantastic = KeyboardButton("Фантастика", f"https://www.kinopoisk.ru/film/{action_id_fantastic}")


    markup.add(button_action, button_adventures, button_comedies, button_fantastic)
    return markup
b = button_menu()