import telebot, random
from ganre.action import action
from ganre.adventures import adventures
from ganre.comedies import comedies
from ganre.fantastic import fantastic

bot = telebot.TeleBot("6900071433:AAEbAguiKOrUv3d0u5lNCxTDoDr7NhoQWx4")

@bot.message_handler(commands=["start"])
def start_message(message):
    bot.send_photo(message.chat.id, "https://telegramguru.info/wp-content/uploads/2022/02/bot-s-filmami-v-telegramme1.jpg")
    bot.send_message(message.chat.id, text= f"RandomMovieBot - ваш личный помощник для выбора фильмов на вечер! Получайте случайные рекомендации прямо из кинопоиска. Просто выберите жанр и дайте боту заботу о выборе. Наслаждайтесь кино без лишних хлопот!\n\n"
                                            f"Ключевые функции:\n"
                                            f"🎬 Случайные фильмы: Получайте рекомендации случайных фильмов из различных жанров.\n"
                                            f"🍿 Широкий выбор: От фантастики до комедии — бот предоставит вам фильмы различных жанров.\n"
                                            f"🌐 Ссылки на Кинопоиск: Легко получайте подробную информацию о фильме, перейдя по ссылке на Кинопоиске."
                                                )
    keyboard = telebot.types.ReplyKeyboardMarkup(True)
    keyboard.row('Выбрать жанр')
    bot.send_message(message.chat.id, text= f"Добро пожаловать в RandomMovieBot! 🎬\n\n"
                                            f"Чтобы начать, нажмите 'Выбрать жанр' в меню.", 
                                            reply_markup=keyboard)


@bot.message_handler(func=lambda message: message.text == 'Выбрать жанр')
def start_message_2(message):
    markup = telebot.types.InlineKeyboardMarkup()
    markup.add(telebot.types.InlineKeyboardButton(text='Боевики', callback_data="action"))
    markup.add(telebot.types.InlineKeyboardButton(text='Приключения', callback_data="adventures"))
    markup.add(telebot.types.InlineKeyboardButton(text='Комедии', callback_data="comedies"))
    markup.add(telebot.types.InlineKeyboardButton(text='Фантастика', callback_data="fantastic"))
    bot.send_message(message.chat.id, text="Из какой категории подобрать фильм", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: True)
def query_handler(call):
    action_id_random = (random.choice(action))
    adventures_id_random = (random.choice(adventures))
    comedies_id_random = (random.choice(comedies))
    fantastic_id_random = (random.choice(fantastic))

    bot.answer_callback_query(callback_query_id=call.id)
    answer = ''
    if call.data == 'action':
        answer = f"https://www.kinopoisk.ru/film/{action_id_random}"
    elif call.data == 'adventures':
        answer = f"https://www.kinopoisk.ru/film/{adventures_id_random}"
    elif call.data == 'comedies':
        answer = f"https://www.kinopoisk.ru/film/{comedies_id_random}"
    elif call.data == 'fantastic':
        answer = f"https://www.kinopoisk.ru/film/{fantastic_id_random}"
    bot.send_message(call.message.chat.id, answer)


bot.polling(non_stop=True)

