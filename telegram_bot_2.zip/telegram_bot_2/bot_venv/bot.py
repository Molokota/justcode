import telebot, env, random
from keyboards.inline_keyboards import b
# API
bot = telebot.TeleBot(env.BOT_TOKEN)

# отправляет фото собак по команде dog
@bot.message_handler(commands=["dog"])
def start(message):
    count = random.randint(1, 5) # генерирует рандомное число для усовного оператора
    # условия выбора картинки
    if count == 1:
        bot.send_photo(message.chat.id, 'https://n1s1.hsmedia.ru/6d/44/b7/6d44b7cefc477eaddfa0b1c2dd36d9c2/600x600_1_a5f839efe9442cf33aa7af5a015e1c77@1494x1494_0xac120004_13547471831688049073.png')
    elif count == 2:
        bot.send_photo(message.chat.id, "https://cdnn1.inosmi.ru/img/24985/10/249851004_0:196:2030:1211_1920x0_80_0_0_78318b59d4ce0cde91f76a1b092765e7.jpg")
    elif count == 3:
        bot.send_photo(message.chat.id, "https://st.peopletalk.ru/wp-content/uploads/2021/08/101550813_300041154339276_6558189288659495336_n-1024x1024.jpg")
    elif count == 4:
        bot.send_photo(message.chat.id, "https://cs6.pikabu.ru/post_img/2017/05/27/9/1495899312168412893.jpg")
    else:
        bot.send_photo(message.chat.id, "https://i.pinimg.com/236x/1c/41/f7/1c41f7529152ef5e81a7908ed98bf043.jpg")


@bot.message_handler()
def button_menu(message):
    bot.send_message(message.chat.id, "Реализовать кнопку Баланс не получилось (((", reply_markup=b)


# @bot.callback_query_handler(func=b)
# def buttom_money(message):
#     bot.edit_message_text(chat_id=callable.message.chat.id, message_id=callable.message.id, text="Данные", reply_markup=b_m)

bot.polling()